## `umoci/oci/...` ##

This package is a reimplementation of several upstream features in
upstream OCI projects, as well as implementing features that _should_ be
maintained upstream (such as `generate`). To this end, this project's
goal is to be completely upstreamable.
