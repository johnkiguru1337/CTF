// Package schema offers utilities to create and maintain a database schema.
package schema
