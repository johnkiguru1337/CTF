# checkansi

![sample](./sample.gif)

## Usage

```bash
go run checkansi/main.go
```

or install

```bash
go install github.com/morikuni/aec/checkansi
```
