//go:build windows
// +build windows

package mtree

import (
	"time"
)

func lchtimes(name string, atime time.Time, mtime time.Time) error {
	return nil
}
