# REST API

```{toctree}
:maxdepth: 1

Main API documentation <rest-api>
api
Main API extensions <api-extensions>
Instance API documentation <dev-lxd>
Events API documentation <events>
Metrics API documentation <metrics>
```
