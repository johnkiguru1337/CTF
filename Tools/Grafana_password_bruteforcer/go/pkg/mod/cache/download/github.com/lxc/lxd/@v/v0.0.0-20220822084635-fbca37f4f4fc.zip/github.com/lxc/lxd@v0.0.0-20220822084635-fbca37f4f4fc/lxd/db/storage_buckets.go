//go:build linux && cgo && !agent

package db

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strings"

	dqliteDriver "github.com/canonical/go-dqlite/driver"

	"github.com/lxc/lxd/lxd/db/query"
	"github.com/lxc/lxd/shared/api"
)

// StorageBucketFilter used for filtering storage buckets with GetStorageBuckets().
type StorageBucketFilter struct {
	Project *string
	Name    *string
}

// StorageBucket represents a database storage bucket record.
type StorageBucket struct {
	api.StorageBucket

	ID      int64
	Project string
}

// GetStoragePoolBuckets returns all storage buckets attached to a given storage pool.
// If there are no buckets, it returns an empty list and no error.
// Accepts filters for narrowing down the results returned. If memberSpecific is true, then the search is
// restricted to buckets that belong to this member or belong to all members.
func (c *ClusterTx) GetStoragePoolBuckets(poolID int64, memberSpecific bool, filters ...StorageBucketFilter) ([]*StorageBucket, error) {
	var q *strings.Builder = &strings.Builder{}
	args := []any{poolID}

	q.WriteString(`
	SELECT
		projects.name as project,
		storage_buckets.id,
		storage_buckets.name,
		storage_buckets.description,
		IFNULL(nodes.name, "") as location
	FROM storage_buckets
	JOIN projects ON projects.id = storage_buckets.project_id
	LEFT JOIN nodes ON nodes.id = storage_buckets.node_id
	WHERE storage_buckets.storage_pool_id = ?
	`)

	if memberSpecific {
		q.WriteString("AND (storage_buckets.node_id = ? OR storage_buckets.node_id IS NULL) ")
		args = append(args, c.nodeID)
	}

	if len(filters) > 0 {
		q.WriteString("AND (")

		for i, filter := range filters {
			// Validate filter.
			if filter.Name != nil && filter.Project == nil {
				return nil, fmt.Errorf("Cannot filter by bucket name if bucket project not specified")
			}

			var qFilters []string

			if filter.Project != nil {
				qFilters = append(qFilters, "projects.name = ?")
				args = append(args, *filter.Project)
			}

			if filter.Name != nil {
				qFilters = append(qFilters, "storage_buckets.name = ?")
				args = append(args, *filter.Name)
			}

			if qFilters == nil {
				return nil, fmt.Errorf("Invalid storage bucket filter")
			}

			if i > 0 {
				q.WriteString(" OR ")
			}

			q.WriteString(fmt.Sprintf("(%s)", strings.Join(qFilters, " AND ")))
		}

		q.WriteString(")")
	}

	var err error
	var buckets []*StorageBucket

	err = query.Scan(c.Tx(), q.String(), func(scan func(dest ...any) error) error {
		var bucket StorageBucket

		err := scan(&bucket.Project, &bucket.ID, &bucket.Name, &bucket.Description, &bucket.Location)
		if err != nil {
			return err
		}

		buckets = append(buckets, &bucket)

		return nil
	}, args...)
	if err != nil {
		return nil, err
	}

	// Populate config.
	for i := range buckets {
		err = storagePoolBucketConfig(c, buckets[i].ID, &buckets[i].StorageBucket)
		if err != nil {
			return nil, err
		}
	}

	return buckets, nil
}

// storagePoolBucketConfig populates the config map of the Storage Bucket with the given ID.
func storagePoolBucketConfig(tx *ClusterTx, bucketID int64, bucket *api.StorageBucket) error {
	q := `
	SELECT
		key,
		value
	FROM storage_buckets_config
	WHERE storage_bucket_id=?
	`

	bucket.Config = make(map[string]string)
	return query.Scan(tx.Tx(), q, func(scan func(dest ...any) error) error {
		var key, value string

		err := scan(&key, &value)
		if err != nil {
			return err
		}

		_, found := bucket.Config[key]
		if found {
			return fmt.Errorf("Duplicate config row found for key %q for storage bucket ID %d", key, bucketID)
		}

		bucket.Config[key] = value

		return nil
	}, bucketID)
}

// GetStoragePoolBucket returns the Storage Bucket for the given Storage Pool ID, Project Name and Bucket Name.
// If memberSpecific is true, then the search is restricted to buckets that belong to this member or belong
// to all members.
func (c *ClusterTx) GetStoragePoolBucket(poolID int64, projectName string, memberSpecific bool, bucketName string) (*StorageBucket, error) {
	filters := []StorageBucketFilter{{
		Project: &projectName,
		Name:    &bucketName,
	}}

	buckets, err := c.GetStoragePoolBuckets(poolID, memberSpecific, filters...)
	bucketsLen := len(buckets)
	if (err == nil && bucketsLen <= 0) || errors.Is(err, sql.ErrNoRows) {
		return nil, api.StatusErrorf(http.StatusNotFound, "Storage bucket not found")
	} else if err == nil && bucketsLen > 1 {
		return nil, api.StatusErrorf(http.StatusConflict, "Storage bucket found on more than one cluster member. Please target a specific member")
	} else if err != nil {
		return nil, err
	}

	return buckets[0], nil
}

// CreateStoragePoolBucket creates a new Storage Bucket.
// If memberSpecific is true, then the storage bucket is associated to the current member, rather than being
// associated to all members.
func (c *Cluster) CreateStoragePoolBucket(ctx context.Context, poolID int64, projectName string, memberSpecific bool, info api.StorageBucketsPost) (int64, error) {
	var err error
	var bucketID int64
	var nodeID any

	if memberSpecific {
		nodeID = c.nodeID
	}

	err = c.Transaction(ctx, func(ctx context.Context, tx *ClusterTx) error {
		// Insert a new Storage Bucket record.
		result, err := tx.tx.Exec(`
		INSERT INTO storage_buckets
		(storage_pool_id, node_id, name, description, project_id)
		VALUES (?, ?, ?, ?, (SELECT id FROM projects WHERE name = ?))
		`, poolID, nodeID, info.Name, info.Description, projectName)
		if err != nil {
			var dqliteErr dqliteDriver.Error
			// Detect SQLITE_CONSTRAINT_UNIQUE (2067) errors.
			if errors.As(err, &dqliteErr) && dqliteErr.Code == 2067 {
				return api.StatusErrorf(http.StatusConflict, "A bucket for that name already exists")
			}

			return err
		}

		bucketID, err = result.LastInsertId()
		if err != nil {
			return err
		}

		// Save config.
		err = storageBucketPoolConfigAdd(tx.tx, bucketID, info.Config)
		if err != nil {
			return err
		}

		return nil
	})
	if err != nil {
		return -1, err
	}

	return bucketID, err
}

// storageBucketPoolConfigAdd inserts Storage Bucket config keys.
func storageBucketPoolConfigAdd(tx *sql.Tx, bucketID int64, config map[string]string) error {
	stmt, err := tx.Prepare(`
	INSERT INTO storage_buckets_config
	(storage_bucket_id, key, value)
	VALUES(?, ?, ?)
	`)
	if err != nil {
		return err
	}

	defer func() { _ = stmt.Close() }()

	for k, v := range config {
		if v == "" {
			continue
		}

		_, err = stmt.Exec(bucketID, k, v)
		if err != nil {
			return fmt.Errorf("Failed inserting config: %w", err)
		}
	}

	return nil
}

// UpdateStoragePoolBucket updates an existing Storage Bucket.
func (c *Cluster) UpdateStoragePoolBucket(ctx context.Context, poolID int64, bucketID int64, info *api.StorageBucketPut) error {
	return c.Transaction(ctx, func(ctx context.Context, tx *ClusterTx) error {
		// Update existing Storage Bucket record.
		res, err := tx.tx.Exec(`
		UPDATE storage_buckets
		SET description = ?
		WHERE storage_pool_id = ? and id = ?
		`, info.Description, poolID, bucketID)
		if err != nil {
			return err
		}

		rowsAffected, err := res.RowsAffected()
		if err != nil {
			return err
		}

		if rowsAffected <= 0 {
			return api.StatusErrorf(http.StatusNotFound, "Storage bucket not found")
		}

		// Save config.
		_, err = tx.tx.Exec("DELETE FROM storage_buckets_config WHERE storage_bucket_id=?", bucketID)
		if err != nil {
			return err
		}

		err = storageBucketPoolConfigAdd(tx.tx, bucketID, info.Config)
		if err != nil {
			return err
		}

		return nil
	})
}

// DeleteStoragePoolBucket deletes an existing Storage Bucket.
func (c *Cluster) DeleteStoragePoolBucket(ctx context.Context, poolID int64, bucketID int64) error {
	return c.Transaction(context.TODO(), func(ctx context.Context, tx *ClusterTx) error {
		// Delete existing Storage Bucket record.
		res, err := tx.tx.Exec(`
			DELETE FROM storage_buckets
			WHERE storage_pool_id = ? and id = ?
		`, poolID, bucketID)
		if err != nil {
			return err
		}

		rowsAffected, err := res.RowsAffected()
		if err != nil {
			return err
		}

		if rowsAffected <= 0 {
			return api.StatusErrorf(http.StatusNotFound, "Storage bucket not found")
		}

		return nil
	})
}

// StorageBucketKeyFilter used for filtering storage bucket keys with GetStorageBucketKeys().
type StorageBucketKeyFilter struct {
	Name *string
}

// StorageBucketKey represents a database storage bucket key record.
type StorageBucketKey struct {
	api.StorageBucketKey

	ID int64
}

// GetStoragePoolBucketKeys returns all storage buckets keys attached to a given storage bucket.
// If there are no bucket keys, it returns an empty list and no error.
// Accepts filters for narrowing down the results returned.
func (c *ClusterTx) GetStoragePoolBucketKeys(bucketID int64, filters ...StorageBucketKeyFilter) ([]*StorageBucketKey, error) {
	var q *strings.Builder = &strings.Builder{}
	args := []any{bucketID}

	q.WriteString(`
	SELECT
		storage_buckets_keys.id,
		storage_buckets_keys.name,
		storage_buckets_keys.description,
		storage_buckets_keys.role,
		storage_buckets_keys.access_key,
		storage_buckets_keys.secret_key
	FROM storage_buckets_keys
	WHERE storage_buckets_keys.storage_bucket_id = ?
	`)

	if len(filters) > 0 {
		q.WriteString("AND (")

		for i, filter := range filters {
			var qFilters []string

			if filter.Name != nil {
				qFilters = append(qFilters, "storage_buckets_keys.name = ?")
				args = append(args, *filter.Name)
			}

			if qFilters == nil {
				return nil, fmt.Errorf("Invalid storage bucket key filter")
			}

			if i > 0 {
				q.WriteString(" OR ")
			}

			q.WriteString(fmt.Sprintf("(%s)", strings.Join(qFilters, " AND ")))
		}

		q.WriteString(")")
	}

	var err error
	var bucketKeys []*StorageBucketKey

	err = query.Scan(c.Tx(), q.String(), func(scan func(dest ...any) error) error {
		var bucketKey StorageBucketKey

		err := scan(&bucketKey.ID, &bucketKey.Name, &bucketKey.Description, &bucketKey.Role, &bucketKey.AccessKey, &bucketKey.SecretKey)
		if err != nil {
			return err
		}

		bucketKeys = append(bucketKeys, &bucketKey)

		return nil
	}, args...)
	if err != nil {
		return nil, err
	}

	return bucketKeys, nil
}

// GetStoragePoolBucketKey returns the Storage Bucket Key for the given Bucket ID and Key Name.
func (c *ClusterTx) GetStoragePoolBucketKey(bucketID int64, keyName string) (*StorageBucketKey, error) {
	filters := []StorageBucketKeyFilter{{
		Name: &keyName,
	}}

	bucketKeys, err := c.GetStoragePoolBucketKeys(bucketID, filters...)
	bucketKeysLen := len(bucketKeys)
	if (err == nil && bucketKeysLen <= 0) || errors.Is(err, sql.ErrNoRows) {
		return nil, api.StatusErrorf(http.StatusNotFound, "Storage bucket key not found")
	} else if err == nil && bucketKeysLen > 1 {
		return nil, api.StatusErrorf(http.StatusConflict, "More than one storage bucket key found")
	} else if err != nil {
		return nil, err
	}

	return bucketKeys[0], nil
}

// CreateStoragePoolBucketKey creates a new Storage Bucket Key.
func (c *Cluster) CreateStoragePoolBucketKey(ctx context.Context, bucketID int64, info api.StorageBucketKeysPost) (int64, error) {
	var err error
	var bucketKeyID int64

	err = c.Transaction(ctx, func(ctx context.Context, tx *ClusterTx) error {
		// Insert a new Storage Bucket Key record.
		result, err := tx.tx.Exec(`
		INSERT INTO storage_buckets_keys
		(storage_bucket_id, name, description, role, access_key, secret_key)
		VALUES (?, ?, ?, ?, ?, ?)
		`, bucketID, info.Name, info.Description, info.Role, info.AccessKey, info.SecretKey)
		if err != nil {
			var dqliteErr dqliteDriver.Error
			// Detect SQLITE_CONSTRAINT_UNIQUE (2067) errors.
			if errors.As(err, &dqliteErr) && dqliteErr.Code == 2067 {
				return api.StatusErrorf(http.StatusConflict, "A bucket key for that name already exists")
			}

			return err
		}

		bucketKeyID, err = result.LastInsertId()
		if err != nil {
			return err
		}

		return nil
	})
	if err != nil {
		return -1, err
	}

	return bucketKeyID, err
}

// UpdateStoragePoolBucketKey updates an existing Storage Bucket Key.
func (c *Cluster) UpdateStoragePoolBucketKey(ctx context.Context, bucketID int64, bucketKeyID int64, info *api.StorageBucketKeyPut) error {
	return c.Transaction(ctx, func(ctx context.Context, tx *ClusterTx) error {
		// Update existing Storage Bucket Key record.
		res, err := tx.tx.Exec(`
		UPDATE storage_buckets_keys
		SET description = ?, role = ?, access_key = ?, secret_key = ?
		WHERE storage_bucket_id = ? and id = ?
		`, info.Description, info.Role, info.AccessKey, info.SecretKey, bucketID, bucketKeyID)
		if err != nil {
			return err
		}

		rowsAffected, err := res.RowsAffected()
		if err != nil {
			return err
		}

		if rowsAffected <= 0 {
			return api.StatusErrorf(http.StatusNotFound, "Storage bucket key not found")
		}

		return nil
	})
}

// DeleteStoragePoolBucketKey deletes an existing Storage Bucket Key.
func (c *Cluster) DeleteStoragePoolBucketKey(ctx context.Context, bucketID int64, keyID int64) error {
	return c.Transaction(context.TODO(), func(ctx context.Context, tx *ClusterTx) error {
		// Delete existing Storage Bucket record.
		res, err := tx.tx.Exec(`
			DELETE FROM storage_buckets_keys
			WHERE storage_bucket_id = ? and id = ?
		`, bucketID, keyID)
		if err != nil {
			return err
		}

		rowsAffected, err := res.RowsAffected()
		if err != nil {
			return err
		}

		if rowsAffected <= 0 {
			return api.StatusErrorf(http.StatusNotFound, "Storage bucket key not found")
		}

		return nil
	})
}
