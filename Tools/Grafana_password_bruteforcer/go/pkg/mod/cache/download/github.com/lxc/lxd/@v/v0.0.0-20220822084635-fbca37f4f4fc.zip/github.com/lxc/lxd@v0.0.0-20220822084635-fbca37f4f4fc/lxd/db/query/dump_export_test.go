package query

var GetTableData = getTableData
var GetEntitiesSchemas = getEntitiesSchemas
