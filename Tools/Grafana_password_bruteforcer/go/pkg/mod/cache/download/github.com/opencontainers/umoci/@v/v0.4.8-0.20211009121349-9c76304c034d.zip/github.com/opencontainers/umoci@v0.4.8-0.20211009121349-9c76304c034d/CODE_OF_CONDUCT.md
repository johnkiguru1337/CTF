<!--
+++
# Hugo Front-matter
title = "Code of Conduct"
aliases = ["/CODE_OF_CONDUCT.md"]
+++
-->

## Code of Conduct ##

As umoci is an OCI project, we are bound by the Open Containers Initative's
[Code of Conduct][oci-coc]. All contributions must abide by the Code of
Conduct.

[oci-coc]: https://github.com/opencontainers/.github/blob/master/CODE_OF_CONDUCT.md

