The LXD team uses GitHub for issue and feature tracking, not for user support.
For information on how to get support, see [Support](https://linuxcontainers.org/lxd/docs/latest/support/).
