package httpbakery

type PublicKeyResponse publicKeyResponse

const MaxDischargeRetries = maxDischargeRetries

var LegacyGetInteractionMethods = legacyGetInteractionMethods
