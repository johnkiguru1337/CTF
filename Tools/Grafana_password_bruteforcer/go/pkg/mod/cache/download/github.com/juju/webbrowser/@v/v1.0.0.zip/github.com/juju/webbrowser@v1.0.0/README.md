# webbrowser
Go helpers for interacting with Web browsers.
