// +build tools

package tools

import (
	_ "github.com/golangci/golangci-lint/cmd/golangci-lint" // CLI mega lint tool
)
