# Configuration
LXD stores the configuration for the following components:

```{toctree}
:maxdepth: 1

containers
Instances <instances>
Preseed files <preseed>
profiles
Projects <projects>
Server settings <server>
Virtual machines <virtual-machines>
```
