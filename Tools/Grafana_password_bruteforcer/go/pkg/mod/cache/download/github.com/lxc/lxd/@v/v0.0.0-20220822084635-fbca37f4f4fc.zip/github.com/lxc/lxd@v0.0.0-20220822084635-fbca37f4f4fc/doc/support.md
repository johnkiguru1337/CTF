# Support

You can find information and ask for user support through the following channels.

% Include content from [../README.md](../README.md)
```{include} ../README.md
    :start-after: <!-- Include start support -->
    :end-before: <!-- Include end support -->
```
