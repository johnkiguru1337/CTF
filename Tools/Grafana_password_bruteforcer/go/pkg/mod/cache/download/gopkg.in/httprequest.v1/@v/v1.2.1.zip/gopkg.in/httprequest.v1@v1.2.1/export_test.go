package httprequest

var AppendURL = appendURL
var MaxErrorBodySize = &maxErrorBodySize
