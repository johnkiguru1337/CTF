package mtree

import (
	"os/user"
)

var lookupGroupID = user.LookupGroupId
