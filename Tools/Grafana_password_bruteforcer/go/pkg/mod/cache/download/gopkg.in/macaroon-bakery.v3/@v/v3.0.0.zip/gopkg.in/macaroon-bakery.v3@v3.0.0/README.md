# The macaroon bakery

This repository is a companion to http://github.com/go-macaroon .
It holds higher level operations for building systems with macaroons.

For documentation, see:

- http://godoc.org/github.com/go-macaroon-bakery/macaroon-bakery/v3/bakery
- http://godoc.org/github.com/go-macaroon-bakery/macaroon-bakery/v3/httpbakery
- http://godoc.org/github.com/go-macaroon-bakery/macaroon-bakery/v3/bakery/checkers
